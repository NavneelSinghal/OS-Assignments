#!/bin/sh

export PINTOS_HOME=`pwd`
export PATH=$PATH:`pwd`/src/utils
